/* init.h
 * Peter Klein
 * Created on March 7, 2013, 5:40 PM
 * Description:
 *
 */

#ifndef INIT_H
#define	INIT_H

void initIO(void);
void initPeripherals1(void);

#endif	/* INIT_H */

