/* uart.h
 * Peter Klein
 * Created on March 19, 2013, 8:06 PM
 * Description:
 *
 * Contains function prototypes and bit masks for setting up the UART(s)
 */

#ifndef UARTH
#define UARTH

#define UART_BUFFER_SIZE		100

#define	TWO_STOP_BITS			0x01	
#define	ONE_STOP_BIT			0x00
#define	ODD_PARITY			0x02
#define	EVEN_PARITY			0x01
#define	NO_PARITY			0x00

#define	U1				0x01
#define U2				0x02

void u1Init(unsigned long baud_rate, char parity_mode, char stop_bits);
void u2Init(unsigned long baud_rate, char parity_mode, char stop_bits);
void uChangeBaud(unsigned long baud_rate, char where);
void uPutChar(char c, char where);
char uGetChar(char where);
char uCharAvailable(char where);
void uFlush(char where);
// TX/RX Interrupt routines!
uint8_t getString(char *buf, uint8_t max_len, uint8_t from, uint8_t to);

#endif
