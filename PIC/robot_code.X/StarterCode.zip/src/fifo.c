/* fifo.c
 * Peter Klein
 * Created on March 9, 2013, 4:01 PM
 * Description: Helper functions to allow for the use of the FIFO structure. Used
 * primarily by the UART to increase the limited hardware buffer. Based on code
 * written by Eric Dickey for the ARM processor.
 */

#include "system.h"
#include "fifo.h"

/*******************************************************************************
 * Function:      fifoInit
 * Inputs:        <FIFO *buffer> the FIFO structure to be initialized
 *                <void *data>  pointer to the data buffer location
 *                <unsigned int length> length of the FIFO
 *                <unsigned char element_size> # of 8-bits (ie char = 1, int = 2)
 * Outputs:       None
 * Description:   This function gets a FIFO structure ready for use. The user
 *                must have first defined the structure, and a buffer for use
 *                Ex.
 *                   FIFO my_fifo;
 *                   char my_fifo_data[10];
 *                   fifoInit(&my_fifo, my_fifo_data, 10, 1);
 * ****************************************************************************/
void fifoInit(FIFO *buffer, void *data, unsigned int length, unsigned char element_size)
{
	buffer->data = data;
	buffer->empty = 1;
	buffer->head = 0;
	buffer->tail = 0;
	buffer->length = length;
	buffer->element_size = element_size;
}

/*******************************************************************************
 * Function:      fifoEmpty
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 * Outputs:       <char> TRUE/FALSE
 * Description:   Returns whether the FIFO specified is empty or not
 * ****************************************************************************/
char fifoEmpty(FIFO *buffer)
{
	return buffer->empty;
}	

/*******************************************************************************
 * Function:      fifoFull
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 * Outputs:       <char> TRUE/FALSE
 * Description:   Returns whether the FIFO specified is full or not
 * ****************************************************************************/
char fifoFull(FIFO *buffer)
{
	if ((buffer->head == (buffer->length-1) && buffer->tail==0) || (buffer->head == (buffer->tail-1)))
		return 1;
	else
		return 0;
}	

/*******************************************************************************
 * Function:      fifoInsert
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 *                <void *c> the data to be inserted
 * Outputs:       None
 * Description:   Puts data into specified FIFO structure
 * ****************************************************************************/
void fifoInsert(FIFO *buffer, void *c)
{
	char *copy_to_here, *copy_from_here = c;
	int count;
	
	if (fifoEmpty(buffer) == 0)
	{
		if (buffer->head < (buffer->length-1))
			buffer->head++;
		else
			buffer->head = 0;
	}	
	
	copy_to_here = (char *)((unsigned int)(buffer->data) + (buffer->head)*(buffer->element_size));
	
	for (count=0;count<buffer->element_size;count++)
	{
		*copy_to_here = *copy_from_here;
		copy_to_here++;
		copy_from_here++;
	}
	
	buffer->empty = 0;
}

/*******************************************************************************
 * Function:      fifoExtract
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 * Outputs:       <void *> data extracted
 * Description:   gets data from specified FIFO
 * ****************************************************************************/
void *fifoExtract(FIFO *buffer)
{
	void *removed_data;
	
	removed_data = (void *)((unsigned int)(buffer->data) + (buffer->tail)*(buffer->element_size));
	
	if (buffer->tail == buffer->head)
		buffer->empty = 1;
	else
	{
		if (buffer->tail < (buffer->length-1))
			buffer->tail++;
		else
			buffer->tail = 0;
	}
	
	return removed_data;
}

/*******************************************************************************
 * Function:      fifoGetUnread
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 * Outputs:       <unsigned int> fifo_size
 * Description:   returns the number of elements that haven't been read
 * ****************************************************************************/
unsigned int fifoGetUnread(FIFO *buffer)
{
	int tail, head;
	
	tail = buffer->tail;
	head = buffer->head;
	
	if (tail < head)
		return head-tail+1;
	if (tail > head)
		return buffer->length - (tail-head) + 1;
	if (tail == head)
		return (buffer->empty == 0);
	
	return 0;
}	

/*******************************************************************************
 * Function:      fifoFlush
 * Inputs:        <FIFO *buffer> the FIFO structure in question
 * Outputs:       None
 * Description:   empties the FIFO
 * ****************************************************************************/
void fifoFlush(FIFO *buffer)
{
	buffer->head = 0;
	buffer->tail = 0;
	buffer->empty = 1;
}	
