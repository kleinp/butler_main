/* lsm330dlc.c
 * Peter Klein
 * Created on April 28, 2013, 7:42 PM
 * Description:
 *
 */

#include "system.h"
#include "lsm330dlc.h"

#include <stdio.h>
#include "uart.h"
#include "messaging.h"

LSM_A_RAW a_raw;
LSM_G_RAW g_raw;
LSM_DATA lsm_reading;

static void lsmWriteRegister(char ag, unsigned char addr, unsigned char data)
{
   int delay;

   if (ag == ACCEL)
   {
      lsmCsaLow();
      SPIGBUF = addr;                  // no auto increment, R/W bit is zero
      SPIGBUF = data;                  // data
      SPIABUF = 0x00;                  // needed to have module read
      SPIABUF = 0x00;                  // needed to have module read
      for(delay=0;delay<28;delay++);   // Wait for transmit to finish
      lsmCsaHigh();
      delay = SPIABUF;                 // dummy read
      delay = SPIABUF;                 // dummy read
      delay = SPIGBUF;                 // dummy read
      delay = SPIGBUF;                 // dummy read
      return;
   }
   if (ag == GYRO)
   {
      lsmCsgLow();
      SPIGBUF = addr;                  // no auto increment, R/W bit is zero
      SPIGBUF = data;                  // data
      for(delay=0;delay<28;delay++);   // Wait for transmit to finish
      lsmCsgHigh();
      delay = SPIGBUF;                 // dummy read
      delay = SPIGBUF;                 // dummy read
      return;
   }
}

static char lsmReadRegister(char ag, unsigned char addr)
{
   int delay;

   if (ag == ACCEL)
   {
      lsmCsaLow();
      SPIGBUF = addr | 0x80;           // no auto increment, R/W bit is one
      SPIGBUF = 0x00;                  // data
      SPIABUF = 0x00;                  // needed to have module read
      SPIABUF = 0x00;                  // needed to have module read
      for(delay=0;delay<28;delay++);   // Wait for transmit to finish
      lsmCsaHigh();
      delay = SPIABUF;                 // dummy read
      delay = SPIABUF;                 // actual data read
      delay = SPIGBUF;                 // dummy read
      delay = SPIGBUF;                 // dummy read
      return delay;
   }
   if (ag == GYRO)
   {
      lsmCsgLow();
      SPIGBUF = addr | 0x80;           // no auto increment, R/W bit is one
      SPIGBUF = 0x00;                  // dummy write
      for(delay=0;delay<28;delay++);   // Wait for transmit to finish
      lsmCsgHigh();
      delay = SPIGBUF;                 // dummy read
      delay = SPIGBUF;                 // actual data read
      return delay;
   }
   return 0;
}

void lsmInit(void)
{
   unsigned int i;

   SPIGCON1bits.MODE16 = 0;   // 8-bit mode
   SPIGCON1bits.SMP = 1;      // Sample data at end of data output time
   SPIGCON1bits.CKE = 0;      // SDO changes on idle to active
   SPIGCON1bits.CKP = 1;      // Clock idles high
   SPIGCON1bits.MSTEN = 1;    // Master mode
   SPIGCON1bits.SPRE = 5;     // Secondary prescale bits (based on 140 Mhz)
   SPIGCON1bits.PPRE = 2;     // Primary prescale bits
   SPIGCON2bits.SPIBEN = 1;   // enhanced buffer mode (8 deep fifo)

   SPIACON1bits.MODE16 = 0;   // 8-bit mode
   SPIACON1bits.SMP = 1;      // Sample data at end of data output time
   SPIACON1bits.CKE = 0;      // SDO changes on idle to active
   SPIACON1bits.CKP = 1;      // Clock idles high
   SPIACON1bits.MSTEN = 1;    // Master mode
   SPIACON1bits.SPRE = 5;     // Secondary prescale bits (based on 140 Mhz)
   SPIACON1bits.PPRE = 2;     // Primary prescale bits
   SPIACON2bits.SPIBEN = 1;   // enhanced buffer mode (8 deep fifo)
   SPIACON1bits.DISSCK = 1;   // Disable CLK output (provided by SPI1)
   SPIACON1bits.DISSDO = 1;   // Disable data (MOSI) output (provided by SPI1)

   SPIGSTATbits.SPIEN = 1;    // Enable the module
   SPIASTATbits.SPIEN = 1;    // Enable the module

   lsmCsaHigh();
   lsmCsgHigh();

   for(i=0;i<100;i++);        // a short delay

   printf("WHOAMI: %X\n\r",0xFF & lsmReadRegister(GYRO,WHO_AM_I_G));

   // ACCEL: 100Hz ODR, Normal power, Z, Y, X Enabled
   lsmWriteRegister(ACCEL, CTRL_REG1_A, 0b01010111);
   // ACCEL: Data LSb @ lower address, +/-2G range, high resolution
   lsmWriteRegister(ACCEL, CTRL_REG4_A, 0b00001000);

   // GYRO: ODR=380, Cut-off=100Hz, Normal power, Z, Y, X Enabled
   lsmWriteRegister(GYRO, CTRL_REG1_G, 0b10111111);

}

void lsmReadMotionData(void)
{
   int count;

   lsmCsaLow();
   lsmCsgLow();

   SPIGBUF = 0xE7;         // Read, Auto address increment
   SPIABUF = 0x00;         // dummy write

   for(count=0;count<7;count++)
   {
      SPIGBUF = 0x00;      // dummy write
      SPIABUF = 0x00;      // dummy write
   }

   // Wait for TX/RX to complete.. At this speed (~15us) it really isn't worth
   // going back to do something else and return when an interrupt occurs
   for(count=0;count<100;count++);

   lsmCsaHigh();
   lsmCsgHigh();

   count = SPIGBUF;        // dummy read (the initial address byte)
   count = SPIABUF;        // dummy read

   // Both SPIXBUF registers should now be filled with 7 data bytes

   //uPutChar('|', U1);
   for(count=0;count<7;count++)
   {
      g_raw.binary_data[count] = SPIGBUF;
      a_raw.binary_data[count] = SPIABUF;

      //printF("%02Xuc,%02Xuc",  g_raw.binary_data[count],  a_raw.binary_data[count]);
   }
   //printF("|\n\r");
}

void lsmRaw2Val(void)
{
   // ACCEL-X
   lsm_reading.ax = (int)((a_raw.out_x_h_a << 8) | a_raw.out_x_l_a);
   // ACCEL-Y
   lsm_reading.ay = (int)((a_raw.out_y_h_a << 8) | a_raw.out_y_l_a);
   // ACCEL-Z
   lsm_reading.az = (int)((a_raw.out_z_h_a << 8) | a_raw.out_z_l_a);
   // GYRO-X
   lsm_reading.gx = (int)((g_raw.out_x_h_g << 8) | g_raw.out_x_l_g);
   // GYRO-Y
   lsm_reading.gy = (int)((g_raw.out_y_h_g << 8) | g_raw.out_y_l_g);
   // GYRO-Z
   lsm_reading.gz = (int)((g_raw.out_z_h_g << 8) | g_raw.out_z_l_g);
}

int lsmGetAx(void)
{
   return lsm_reading.ax;
}

int lsmGetAz(void)
{
   return lsm_reading.az;
}

int lsmGetGy(void)
{
   return lsm_reading.gy;
}

void lsmAddAngle(int angle)
{
   lsm_reading.angle = angle;
}

void lsmVal2Angles(LSM_ANGLES *data, double dt)
{
   LSM_ANGLES tmp;
   data = &tmp;
   
   tmp.x = (0.98)*(tmp.x + lsm_reading.gx*dt) +
             (0.02)*(lsm_reading.ax*57.2957795);

   tmp.y = (0.98)*(tmp.y + lsm_reading.gy*dt) +
             (0.02)*(lsm_reading.ay*57.2957795);

   tmp.z = (0.98)*(tmp.z + lsm_reading.gz*dt) +
             (0.02)*(lsm_reading.az*57.2957795);

}

/*******************************************************************************
 * Function:      msgBuild_18
 * Inputs:        <int bnum> which buffer the data should go into
 * Outputs:       None
 * Description:   This function fills the buffer <bnum> with the data in
 *                message type 16, as defined by PACKET_16 in messaging.h
 *
 *                ** THIS FUNCTION NEEDS TO BE AUTO-GENERATED ALONG WITH
 *                   NECESSARY HEADER FILES **
 * ****************************************************************************/

uint16_t msg16_counter = 0;

void msgBuild_18(int16_t bnum)
{
   // Header setup information (static)
   tx_buffer[bnum].header.ack = FALSE;
   tx_buffer[bnum].header.sd = 1;
   tx_buffer[bnum].header.type = 18;

   // Data to be filled in
   tx_buffer[bnum].data_18.counter = msg16_counter;
   msg16_counter++;

   tx_buffer[bnum].data_18.Ax = lsm_reading.ax;
   tx_buffer[bnum].data_18.Ay = lsm_reading.ay;
   tx_buffer[bnum].data_18.Az = lsm_reading.az;

   tx_buffer[bnum].data_18.Gx = lsm_reading.gx;
   tx_buffer[bnum].data_18.Gy = lsm_reading.gy;
   tx_buffer[bnum].data_18.Gz = lsm_reading.gz;
   tx_buffer[bnum].data_18.angle = lsm_reading.angle;
}