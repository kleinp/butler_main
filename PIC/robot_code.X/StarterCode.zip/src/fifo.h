/* fifo.h
 * Peter Klein
 * Created on March 9, 2013, 3:40 PM
 * Description: defines the FIFO buffer structure. Used primarily by the UART to
 * increase the standard hardware buffer size. Based on ARM code written by
 * Eric Dickey.
 */

#ifndef FIFO_H
#define FIFO_H

typedef struct FIFO
{
    char *data;                     // point to the first byte of the first element
    unsigned int head;              // index of the newest element
    unsigned int tail;              // index of the oldest element
    char empty;                     // TRUE if empty
    unsigned int length;            // number of elements in the array
    unsigned char element_size;     // size of each element
} FIFO;

// Function prototypes

void fifoInit(FIFO *buffer, void *data, unsigned int length, unsigned char element_size);
char fifoEmpty(FIFO *buffer);
char fifoFull(FIFO *buffer);
void fifoInsert(FIFO *buffer, void *c);
void *fifoExtract(FIFO *buffer);
unsigned int fifoGetUnread(FIFO *buffer);
void fifoFlush(FIFO *buffer);

#endif  /* FIFO_H */
