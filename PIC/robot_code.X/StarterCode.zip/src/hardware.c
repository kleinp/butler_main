/* hardware.c
 * Peter Klein
 * Created on August 18, 2013, 1:54 PM
 * Description:
 *
 */

#include "system.h"
#include "hardware.h"
#include "math.h"

void initMotorPWM(void)
{
   // LM_A
   OC1CON1 = 0;                  // clear configuration registers
   OC1CON2 = 0;
   OC1CON1bits.OCTSEL = 0b111;   // Use peripheral clock
   OC1R = MAX_OC_VAL;            // 100% duty cycle to start
   OC1RS = MAX_OC_VAL;           // Period counter for ~20kHz
   OC1CON2bits.SYNCSEL = 0x1F;   // No sync or trigger source for this motor
   OC1CON1bits.OCM = 0b110;      // Edge aligned PWM
   
   // LM_B
   OC2CON1 = 0;                  // clear configuration registers
   OC2CON2 = 0;
   OC2CON1bits.OCTSEL = 0b111;   // Use peripheral clock
   OC2R = MAX_OC_VAL;            // 100% duty cycle to start
   OC2CON2bits.SYNCSEL = 0x1;    // Syncronize OC2 PWM to OC1 PWM
   OC2CON1bits.OCM = 0b110;      // Edge aligned PWM

   // RM_A
   OC3CON1 = 0;                  // clear configuration registers
   OC3CON2 = 0;
   OC3CON1bits.OCTSEL = 0b111;   // Use peripheral clock
   OC3R = MAX_OC_VAL;            // 100% duty cycle to start
   OC3CON2bits.SYNCSEL = 0x1;    // Syncronize OC3 PWM to OC1 PWM
   OC3CON1bits.OCM = 0b110;      // Edge aligned PWM

   // RM_B
   OC4CON1 = 0;                  // clear configuration registers
   OC4CON2 = 0;
   OC4CON1bits.OCTSEL = 0b111;   // Use peripheral clock
   OC4R = MAX_OC_VAL;            // 100% duty cycle to start
   OC4CON2bits.SYNCSEL = 0x1;    // Syncronize OC4 PWM to OC1 PWM
   OC4CON1bits.OCM = 0b110;      // Edge aligned PWM
}

// Provide speed -50 -> 50 for each motor
// Speeds less than 0 cause a change in direction
void setMotorOutputs(char left, char right)
{
   if (left > 50)          // coerce inputs to within +/- 50
      left = 50;
   if (left < -50)
      left =-50;

   if (right > 50)
      right = 50;
   if (right < -50)
      right = -50;

   if (left < 0)
   {
      OC1R = MAX_OC_VAL;
      OC2R = MAX_OC_VAL - MAX_OC_VAL_DIV*(unsigned int)fabs(left);
      DIR_L_OUT = 0;
   }
   else
   {  
      OC1R = MAX_OC_VAL - MAX_OC_VAL_DIV*(unsigned int)fabs(left);
      OC2R = MAX_OC_VAL;
      DIR_L_OUT = 1;
   }

   if (right < 0)
   {
      OC3R = MAX_OC_VAL;
      OC4R = MAX_OC_VAL - MAX_OC_VAL_DIV*(unsigned int)fabs(right);
      DIR_R_OUT = 0;
   }
   else
   {
      OC3R = MAX_OC_VAL - MAX_OC_VAL_DIV*(unsigned int)fabs(right);
      OC4R = MAX_OC_VAL;
      DIR_R_OUT = 1;
   }

}

ENC64 cnts_left;
ENC64 cnts_right;

void initEncoder(void)
{
   QEI1CONbits.CCM = 0b01;    // External clock with direction
   QEI1CONbits.QEIEN = 1;     // Enable the module

   QEI2CONbits.CCM = 0b01;    // External clock with direction
   QEI2CONbits.QEIEN = 1;     // Enable the module

   cnts_left.position = 0;
   cnts_right.position = 0;
}

int64_t getEncPos(char side)
{
   switch(side)
   {
      case LEFT:
         cnts_left.reg_vals[4] = POS1CNTL;
         cnts_left.reg_vals[3] = POS1HLD;
         return cnts_left.position;
      case RIGHT:
         cnts_right.reg_vals[4] = POS2CNTL;
         cnts_right.reg_vals[3] = POS2HLD;
         return cnts_right.position;
      default:
         return 0;
   }
}

void initEEprom(void)
{
   
}