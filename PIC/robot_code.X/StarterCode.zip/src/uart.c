/* uart.h
 * Peter Klein
 * Created on March 19, 2013, 8:06 PM
 * Description:
 *
 * Contains functions for initializing, sending, and receiving characters
 * through the UART. Uses built in 4-byte FIFO, but also expands to a much
 * larger FIFO. Contains putChar and getChar functions
 */

#include "system.h"
#include "uart.h"
#include "fifo.h"

// UART 1,2 can be expanded to include others
FIFO rx_buffer_u1;
FIFO tx_buffer_u1;
FIFO rx_buffer_u2;
FIFO tx_buffer_u2;

char rx_data_u1[UART_BUFFER_SIZE];
char tx_data_u1[UART_BUFFER_SIZE];
char rx_data_u2[UART_BUFFER_SIZE];
char tx_data_u2[UART_BUFFER_SIZE];

/*******************************************************************************
 * Function:      u1Init
 * Inputs:        <unsigned long baud_rate> desired baud rate of UART
 *                <char parity_mode> ODD_PARITY/EVEN_PARITY/NO_PARITY
 *                <char stop_bits> ONE_STOP_BIT/TWO_STOP_BITS
 * Outputs:       None
 * Description:   This function initializes the UART registers, extended FIFO
 *                buffer, and interrupts for complete putChar and getChar
 *                functionality.
 * ****************************************************************************/
void u1Init(unsigned long baud_rate, char parity_mode, char stop_bits)
{
	fifoInit(&rx_buffer_u1, rx_data_u1, UART_BUFFER_SIZE, 1);
	fifoInit(&tx_buffer_u1, tx_data_u1, UART_BUFFER_SIZE, 1);
	
	U1MODE = 0;		// reset UART
	
	// 1 or 2 stop bits
	U1MODEbits.STSEL = stop_bits;
	
	// Parity type
	U1MODEbits.PDSEL = parity_mode;

   // Set baud rate
   U1MODEbits.BRGH = 1;
   uChangeBaud(baud_rate, U1);
	
	// Set up interrupts
	U1STAbits.UTXISEL1 = 1;		// interrupt when the last byte goes to be sent out
	U1STAbits.UTXISEL0 = 0;
	U1STAbits.URXISEL1 = 0;		// interrupt when there is anything in RX buffer
	U1STAbits.URXISEL0 = 0;	
	
	IEC0bits.U1RXIE = 1;			// enable vectored interrupt for tx and rx
	IEC0bits.U1TXIE = 1;
	
	IPC2bits.U1RXIP = 1;       // set interrupt priority to 1 (pretty low)
	IPC3bits.U1TXIP = 1;
	
	IFS0bits.U1RXIF = 0;       // clear interrupt flags
   IFS0bits.U1TXIF = 0;

   // Enable UART
	U1MODEbits.UARTEN = 1;
	U1STAbits.UTXEN = 1;			// enable tx
}	

/*******************************************************************************
 * Function:      u2Init
 * Inputs:        <unsigned long baud_rate> desired baud rate of UART
 *                <char parity_mode> ODD_PARITY/EVEN_PARITY/NO_PARITY
 *                <char stop_bits> ONE_STOP_BIT/TWO_STOP_BITS
 * Outputs:       None
 * Description:   This function initializes the UART registers, extended FIFO
 *                buffer, and interrupts for complete putChar and getChar
 *                functionality.
 * ****************************************************************************/
void u2Init(unsigned long baud_rate, char parity_mode, char stop_bits)
{
	fifoInit(&rx_buffer_u2, rx_data_u2, UART_BUFFER_SIZE, 1);
	fifoInit(&tx_buffer_u2, tx_data_u2, UART_BUFFER_SIZE, 1);

	U2MODE = 0;		// reset UART

	// 1 or 2 stop bits
	U2MODEbits.STSEL = stop_bits;

	// Parity type
	U2MODEbits.PDSEL = parity_mode;

   // Set baud rate
   U2MODEbits.BRGH = 1;
   uChangeBaud(baud_rate, U2);

	// Set up interrupts
	U2STAbits.UTXISEL1 = 1;		// interrupt when the last byte goes to be sent out
	U2STAbits.UTXISEL0 = 0;
	U2STAbits.URXISEL1 = 0;		// interrupt when there is anything in RX buffer
	U2STAbits.URXISEL0 = 0;

	IEC1bits.U2RXIE = 1;			// enable vectored interrupt for tx and rx
	IEC1bits.U2TXIE = 1;

	IPC7bits.U2RXIP = 1;       // set interrupt priority to 1 (pretty low)
	IPC7bits.U2TXIP = 1;

	IFS1bits.U2RXIF = 0;       // clear interrupt flags
   IFS1bits.U2TXIF = 0;

   // Enable UART
	U2MODEbits.UARTEN = 1;
	U2STAbits.UTXEN = 1;			// enable tx
}

/*******************************************************************************
 * Function:      uChangeBaud
 * Inputs:        <unsigned long baud_rate> desired baud rate of UART
 *                <char where> which UART should be affected 
 * Outputs:       None
 * Description:   This function updates the UxBRG based on the desired baud
 *                rate given the current processor fequency
 * ****************************************************************************/
void uChangeBaud(unsigned long baud_rate, char where)
{
   unsigned long clock_freq = getClockFreq();
   
   switch(where)
   {
      case U1:
         U1BRG = (unsigned int)(clock_freq/(8*baud_rate)-1);
         break;
      case U2:
         U2BRG = (unsigned int)(clock_freq/(8*baud_rate)-1);
         break;
      default:
         break;
   }
}

/*******************************************************************************
 * Function:      uPutChar
 * Inputs:        <char where> which UART should be affected
 * Outputs:       None
 * Description:   Places a character into the software FIFO for transmission.
 *                If not already going, this function starts the TX process by
 *                putting a character into the hardare buffer
 * ****************************************************************************/
void uPutChar(char c, char where)
{
   static char *val;

	switch(where)		// which buffer shall the character be put into?
	{
		case U1:
			while(fifoFull(&tx_buffer_u1));  // wait for there to be space
                                          // in the software buffer

         fifoInsert(&tx_buffer_u1, &c);

			if (!U1STAbits.UTXBF)            // Start the tx process
         {
            val = fifoExtract(&tx_buffer_u1);
            U1TXREG = *val;
         }
				
			break;
		case U2:
			while(fifoFull(&tx_buffer_u2));  // wait for there to be space
                                          // in the software buffer

         fifoInsert(&tx_buffer_u2, &c);
         
			if (!U2STAbits.UTXBF)            // Start the tx process
         {
            val = fifoExtract(&tx_buffer_u2);
            U2TXREG = *val;
         }
				
			break;
		default:
			break;
	}
}

/*******************************************************************************
 * Function:      uGetChar
 * Inputs:        <char where> which UART should be affected
 * Outputs:       <char c> returned character
 * Description:   Returns the oldest character in the software receive FIFO
 * ****************************************************************************/
char uGetChar(char where)
{
	char *c;
	
	switch(where)		// which buffer shall the character be gotten from?
	{
		case U1:
			while(fifoEmpty(&rx_buffer_u1));    // wait for a character
			c = fifoExtract(&rx_buffer_u1);
			break;
		case U2:
			while(fifoEmpty(&rx_buffer_u2));
			c = fifoExtract(&rx_buffer_u2);
			break;
		default:
			break;
	}
	return *c;
}

/*******************************************************************************
 * Function:      uCharAvailable
 * Inputs:        <char where> which UART should be affected
 * Outputs:       <char available> character available? 1=yes 0=no
 * Description:   This function returns a 1 if there is an available character
 *                in the software receive buffer, and a 0 if there is not.
 *                This function should be used in conjunction with uGetChar()
 *                as it is a blocking function if there are no characters
 *                available to get.
 * ****************************************************************************/
char uCharAvailable(char where)
{
	char available = 0;
	
	switch(where)
	{
		case U1:
			available = !fifoEmpty(&rx_buffer_u1);
			break;
		case U2:
			available = !fifoEmpty(&rx_buffer_u2);
			break;
		default:
			break;
	}
	return available;
}	

/*******************************************************************************
 * Function:      uFlush
 * Inputs:        <char where> which UART should be affected
 * Outputs:       None
 * Description:   This function flushes input and output software buffers of
 *                the module
 * ****************************************************************************/
void uFlush(char where)
{
	switch(where)
	{
		case U1:
			fifoFlush(&rx_buffer_u1);
			fifoFlush(&tx_buffer_u1);
			break;
		case U2:
			fifoFlush(&rx_buffer_u2);
			fifoFlush(&tx_buffer_u2);
			break;
		default:
			break;
	}
}

/*******************************************************************************
 * Function:      _U1/2RXInterrupt / _U1/2TXInterrupt
 * Inputs:        None
 * Outputs:       None
 * Description:   These functions are the vectored interrupts of the UART module
 *                For transmit, they more characters from the software FIFO
 *                buffer into the 4-byte deep hardware FIFO. To receive, they
 *                move characters from the 4-byte deep hardware FIFO into the
 *                software buffer. The 4-byte deep hardware FIFO allows these
 *                functions to operate at a lower interrupt priority, since
 *                at a normal 115200 baud, it would take ~0.3 ms to fill the
 *                buffer
 * ****************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _U1RXInterrupt(void)
{
	static char val;
	while(U1STAbits.URXDA)	// there is data in the built-in RX FIFO
	{
		val = U1RXREG;
		fifoInsert(&rx_buffer_u1, &val);		// move the data to the bigger "software" buffer
		
	}
		
	IFS0bits.U1RXIF = 0;
}

void __attribute__((interrupt, no_auto_psv)) _U1TXInterrupt(void)
{
	char *val;
	
	while(!U1STAbits.UTXBF && !fifoEmpty(&tx_buffer_u1))		// there is space in the built-in TX FIFO
	{
		val = fifoExtract(&tx_buffer_u1);
		U1TXREG = *val;
	}
	
	IFS0bits.U1TXIF = 0;
}	

void __attribute__((interrupt, no_auto_psv)) _U2RXInterrupt(void)
{
	static char val;
	while(U2STAbits.URXDA)	// there is data in the built-in RX FIFO
	{
		val = U2RXREG;
		fifoInsert(&rx_buffer_u2, &val);		// move the data to the bigger "software" buffer

	}

	IFS1bits.U2RXIF = 0;
}

void __attribute__((interrupt, no_auto_psv)) _U2TXInterrupt(void)
{
	char *val;
	
	while(!U2STAbits.UTXBF && !fifoEmpty(&tx_buffer_u2))		// there is space in the built-in TX FIFO
	{
		val = fifoExtract(&tx_buffer_u2);
		U2TXREG = *val;
	}
		
	IFS1bits.U2TXIF = 0;
}	

/*******************************************************************************
 * Function:      write
 * Inputs:        <int handle> where to write the data. Currently only works for uart
 *                <void *buffer> pointer to data
 *                <unsigned int len> length of data to write
 * Outputs:       <int len> number of characters written
 * Description:   This function replaces the built-in write function so that
 *                it can be re-directed to UART1
 * ****************************************************************************/
int __attribute__((__section__(".libc.write"))) write(int handle, void *buffer, unsigned int len)
{
   int i;
   switch (handle)
   {
      default:
      case 0:
      case 1:
      case 2:
         for (i=len;i;i--)
            uPutChar(*(char*)buffer++, U1);
         break;
   }
   return(len);
}

/*******************************************************************************
 * Function:      getString
 * Inputs:        <char *buf> The buffer the string should be stored in
 *                <uint8 max_len> The maximum number of characters to return
 *                <uint8 from> from which UART the characters should come from
 *                <uint8 to> which UART the characters should be echo'd to, or
 *                           use NULL for none.
 * Outputs:       <int len> number of characters returned in buffer, no including
 *                          the null (\0) character
 * Description:   Gets a string of defined length or shorter from a UART buffer.
 *                Echoes the input back to the user real-time, and can handle
 *                backspace!
 * ****************************************************************************/
uint8_t getString(char *buf, uint8_t max_len, uint8_t from, uint8_t to)
{
   char c;
   uint8_t count = 0;

   while(count < max_len-1)
   {
      c = uGetChar(from);

      if (c == '\n' || c == '\r')         // ENTER pressed
         break;
      else if (c >= ' ' && c <= '~')      // ASCII character entered
      {
         uPutChar(c, to);
         *buf++ = c;
         count++;
      }
      else if (c == '\b' && count > 0)    // Backspace (don't allow backup past first char)
      {
         uPutChar('\b', to);
         uPutChar(' ', to); 
         uPutChar('\b', to);
         buf--;
         count--;
      }
   }
   
   *buf = '\0';      // null terminate
   return(count);
}
