/* robot.c
 * Peter Klein
 * Created on August 18, 2013, 1:44 PM
 * Description:
 *
 */

#include "system.h"
#include "robot.h"
#include "hardware.h"
#include "lsm330dlc.h"
#include "messaging.h"
#include "uart.h"
#include "math.h"

LSM_ANGLES theta;
LSM_ANGLES *p_theta = &theta;

char led_count = 0;
char motor_speed = 0;

void __attribute__((__interrupt__,no_auto_psv)) _T1Interrupt(void)
{
   double angle = 0;
   double ax, az, gy, tmp;

   led_count++;
   if (led_count > 29)
   {
      led1Toggle();
      led_count = 0;

      setMotorOutputs(motor_speed, motor_speed);
      motor_speed++;

      if (SWITCH2)
         motor_speed=0;

      //printF("Left: %i  Right: %i\n\r", POS1CNTL, POS2CNTL);
   }

   /*
   lsmReadMotionData();
   lsmRaw2Val();
   
   ax = (double)lsmGetAx();
   az = (double)lsmGetAz();
   gy = (double)lsmGetGy();

   ax = ax/16384.0;
   az = az/16384.0;
   gy = gy/131.072;

   tmp = atan2(az, ax)*180/3.14159;

   angle = (0.98)*(angle + gy*0.01) + (0.02)*tmp;
   lsmAddAngle((int)(angle * 100));
   msgBuild_18(0);
   msgSend(0, U1);
   */
   
   IFS0bits.T1IF = 0;
}